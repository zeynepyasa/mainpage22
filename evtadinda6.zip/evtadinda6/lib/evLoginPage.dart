import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class evLoginPage extends StatelessWidget {
  evLoginPage({
    key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff7f6ff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: -64.0, end: -12.0),
            Pin(size: 451.0, start: -163.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/login1.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: -63.0, end: -13.0),
            Pin(size: 451.0, start: -163.0),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0.933, -0.043),
                  end: Alignment(-0.277, 0.973),
                  colors: [const Color(0xff19d3e1), const Color(0x5720c2ff)],
                  stops: [0.0, 1.0],
                ),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 30.0, end: 30.0),
            Pin(size: 523.0, middle: 0.5398),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                borderRadius: BorderRadius.circular(34.0),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0x4dcdccf1),
                    offset: Offset(0, 5),
                    blurRadius: 15,
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 117.0, middle: 0.5),
            Pin(size: 117.0, start: 18.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/logo.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.034, -0.457),
            child: Container(
              width: 226.0,
              height: 28.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                borderRadius: BorderRadius.circular(22.0),
                border: Border.all(width: 1.0, color: const Color(0xffeaeaf5)),
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.445, -0.448),
            child: SizedBox(
              width: 112.0,
              height: 40.0,
              child: Stack(
                children: <Widget>[
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xff19e1dd),
                      borderRadius: BorderRadius.circular(22.0),
                    ),
                    margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 12.0),
                  ),
                  Pinned.fromPins(
                    Pin(size: 54.0, middle: 0.5),
                    Pin(start: 5.0, end: 0.0),
                    child: Text(
                      'Giriş Yap\n',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 12,
                        color: const Color(0xffffffff),
                        fontWeight: FontWeight.w600,
                      ),
                      softWrap: false,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.321, -0.454),
            child: SizedBox(
              width: 45.0,
              height: 17.0,
              child: Text(
                'Kayıt Ol',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff19e0dc),
                ),
                softWrap: false,
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.032, -0.217),
            child: SizedBox(
              width: 225.0,
              height: 1.0,
              child: SvgPicture.string(
                _svg_kf5,
                allowDrawingOutsideViewBox: true,
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.032, -0.096),
            child: SizedBox(
              width: 225.0,
              height: 1.0,
              child: SvgPicture.string(
                _svg_q4zva7,
                allowDrawingOutsideViewBox: true,
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.459, -0.255),
            child: SizedBox(
              width: 105.0,
              height: 17.0,
              child: Text(
                'Telefon Numarası',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffa8a7a7),
                ),
                softWrap: false,
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.454, -0.044),
            child: SizedBox(
              width: 93.0,
              height: 15.0,
              child: Text(
                'Şifreni mi unuttun?',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffa8a7a7),
                ),
                softWrap: false,
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.582, -0.132),
            child: SizedBox(
              width: 26.0,
              height: 17.0,
              child: Text(
                'Şifre',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffa8a7a7),
                ),
                softWrap: false,
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.0, 0.395),
            child: SizedBox(
              width: 29.0,
              height: 35.0,
              child: Text(
                'veya\n',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffa8a7a7),
                ),
                softWrap: false,
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.027, 0.185),
            child: Container(
              width: 225.0,
              height: 44.0,
              decoration: BoxDecoration(
                color: const Color(0xff19e0dc),
                borderRadius: BorderRadius.circular(22.0),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.003, 0.179),
            child: SizedBox(
              width: 32.0,
              height: 20.0,
              child: Text(
                'Giriş',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  fontWeight: FontWeight.w600,
                ),
                softWrap: false,
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.372, 0.522),
            child: Container(
              width: 47.0,
              height: 46.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                border: Border.all(width: 1.0, color: const Color(0xffeeeef6)),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.351, 0.513),
            child: Container(
              width: 30.0,
              height: 31.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/google_logo.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.012, 0.522),
            child: Container(
              width: 47.0,
              height: 46.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                border: Border.all(width: 1.0, color: const Color(0xffeeeef6)),
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.396, 0.522),
            child: Container(
              width: 47.0,
              height: 46.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                border: Border.all(width: 1.0, color: const Color(0xffeeeef6)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 160.7, end: 25.7),
            Pin(size: 180.0, end: -77.9),
            child: Transform.rotate(
              angle: 2.7751,
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: const AssetImage('assets/images/yesillik.png'),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 119.0, end: -22.0),
            Pin(size: 107.0, end: -33.0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/domates.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(-0.366, 0.512),
            child: Container(
              width: 15.0,
              height: 31.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/facebook_logo.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.0, 0.509),
            child: Container(
              width: 30.0,
              height: 25.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/twitter_logo.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0.577, -0.125),
            child: Container(
              width: 20.0,
              height: 19.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage('assets/images/eye.png'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_kf5 =
    '<svg viewBox="72.5 317.5 225.3 1.0" ><path transform="translate(72.5, 317.5)" d="M 0 0 L 225.2669677734375 0" fill="none" stroke="#eaeaf5" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_q4zva7 =
    '<svg viewBox="72.5 366.5 225.3 1.0" ><path transform="translate(72.5, 366.5)" d="M 0 0 L 225.2669677734375 0" fill="none" stroke="#eaeaf5" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
