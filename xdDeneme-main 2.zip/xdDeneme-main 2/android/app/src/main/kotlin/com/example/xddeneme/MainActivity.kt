package com.example.xddeneme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
